package com.companyname.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.companyname.core.Employee;

public class TestSpringCoreArray {

	public static void main(String[] args) {
			
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("config/spring-config.xml");

		Object object=applicationContext.getBean("employeeBean");
		Employee employee=(Employee) object;
		System.out.println("Employee Id: "+employee.getEmployeeId());
		System.out.println("Employee Name: "+employee.getEmployeeName());
		System.out.println("Employee Address: ");
		String address[]=employee.getAddress();
		for(int i=0;i<address.length;i++){
			System.out.println(address[i]);
		}
		
		
		
		
	}

}
