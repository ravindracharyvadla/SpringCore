package com.companyname.core;

import java.util.List;

public class Customer1 {

	private int customerId;
	private String customerName;
	private List<Account1> listOfAccounts;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public List<Account1> getListOfAccounts() {
		return listOfAccounts;
	}
	public void setListOfAccounts(List<Account1> listOfAccounts) {
		this.listOfAccounts = listOfAccounts;
	}
	
	
	
}
