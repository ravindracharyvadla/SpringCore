package com.companyname.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.companyname.core.Account1;
import com.companyname.core.Customer1;

public class TestSpringArrayList {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("config/spring-config.xml");

		Object object=applicationContext.getBean("customer1Bean");
		Customer1 customer=(Customer1) object;
		
		System.out.println("-----Customer Details-----------");
		System.out.println("Customer Id: "+customer.getCustomerId());
		System.out.println("Customer Name: "+customer.getCustomerName());
		
		System.out.println("------Account Details--------");
		List<Account1> accountList=customer.getListOfAccounts();
		for(Account1 acc:accountList){
			System.out.println("Account Number: "+acc.getAccountNumber());
			System.out.println("Account Holder Name: "+acc.getAccountHolderName());
		}

	}

}






