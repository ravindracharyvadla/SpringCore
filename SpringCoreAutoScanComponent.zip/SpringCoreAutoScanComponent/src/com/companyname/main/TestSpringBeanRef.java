package com.companyname.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.companyname.core.Customer;

public class TestSpringBeanRef {

	public static void main(String[] args) {
			
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("config/spring-config.xml");

		Object object=applicationContext.getBean("customerObject");
		Customer customer=(Customer) object;
		
		customer.getAccount().setAccountNumber(44556677);
		customer.getAccount().setAccountHolderName("Rod Johnson");
		
		customer.setCustomerId(1122);
		customer.setCustomerName("John Son");
		
		System.out.println("-----Customer Details-----------------");
		System.out.println("Customer Id: "+customer.getCustomerId());
		System.out.println("Customer Name: "+customer.getCustomerName());
		
		System.out.println("-----Account Details-----------------");
		System.out.println("Account Number: "+customer.getAccount().getAccountNumber());
		System.out.println("Account Holder Name: "+customer.getAccount().getAccountHolderName());
	
		
	}

}
